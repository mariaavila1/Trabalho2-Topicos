/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arquivostextos;

import java.util.Scanner;

/**
 *
 * @author stell
 */
public class Caracter {
    int posicoes;
        Scanner teclado = new Scanner(System.in);
           
            String[] palavras = diretorio.split(" ");
            for(int cont=0;cont<palavras[cont].length();cont++){
            if(palavras[cont].length()== posicoes){
                System.out.println(palavras);
            }
        }
       }
}
